package Ejercicio1;

public class Punto {
	
	/*Coordenadas*/
	
	int x;
	int y;

}
