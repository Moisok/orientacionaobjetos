package Ejercicio5_3;

public class UD5_Ejercicio5_3 {
	
public static void main(String[] args) {
		
		rectangulo Cuadrado1 = new rectangulo (5,9,8,7);
		

		/*Primer rectangulo*/
		
		Cuadrado1.mostrardatos();
		
		System.out.println (" ");
		
		Cuadrado1.perimetro();
		
		System.out.println (" ");
		
		Cuadrado1.area();
		
		System.out.println (" ");
		
		rectangulo.RECaleatorio(Cuadrado1);
		
		Cuadrado1.mostrardatos();
		
		System.out.println (" ");
		
		Cuadrado1.perimetro();
		
		System.out.println (" ");
		
		Cuadrado1.area();
		
	}

}






