package Ejercicio4;

public class Articulo {
	
	String nombre;
	double precio;
	int iva;
	int stock;

}
