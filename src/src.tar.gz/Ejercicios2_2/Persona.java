package Ejercicios2_2;

public class Persona {

	int dni;
	
	String nombre;

	String apellido;

	int edad;
	
	public Persona (String nombre, String apellido, int edad, int  dni) {
		
		this.nombre =nombre;
		
		this.apellido = apellido;
		
		this.edad = edad;
		
		this.dni = dni;
		
	}


}

