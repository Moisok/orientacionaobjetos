package Ejercicios2_2;

public class UD5_Ejercicio2_2 {
	
public static void main(String[] args) {
		
		Persona Manuel = new Persona ("Manuel","Cervantes",54,54577809);
		
		Persona Alfonso = new Persona ("Alfonso","Garcia",21,578963254);

		System.out.println (" ");
		System.out.println ("Nombre: " + Manuel.nombre);
		System.out.println ("Apellido: " + Manuel.apellido);
		System.out.println ("Edad: " + Manuel.edad);
		System.out.println ("DNI: " + Manuel.dni);
		
		System.out.println (" ");
		System.out.println ("Nombre: " + Alfonso.nombre);
		System.out.println ("Apellido: " + Alfonso.apellido);
		System.out.println ("Edad: " + Alfonso.edad);
		System.out.println ("DNI: " + Alfonso.dni);

	}

}


