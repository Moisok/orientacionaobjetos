package Ejercicios2_1;

public class Punto {
	
	/*Coordenadas*/
	
	int x;
	
	int y;
	
	public Punto (int x, int y) {
		
		this.x=x;
		
		this.y=y;
	}

}
