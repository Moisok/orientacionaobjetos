package Ejercicio3;

public class rectangulo {
	
	int x1;
	int y1;
	int x2;
	int y2;

}
