package Ejercicio2;

public class Persona {
	
		int dni;
		
		String nombre;

		String apellido;
	
		int edad;
	

}
