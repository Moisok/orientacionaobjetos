package Ejercicios2_4;

public class Articulo {
	
		String nombre;
		
		double precio;
		
		int iva;
		
		int stock;
		
		public Articulo (String nombre, double precio, int iva, int stock) {
			
			this.nombre=nombre;
			
			this.precio=precio;
			
			this.iva=iva;
			
			this.stock=stock;
			
		}

	}



